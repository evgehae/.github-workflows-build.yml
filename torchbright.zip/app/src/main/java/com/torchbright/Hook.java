package com.torchbright;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.util.Log;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class Hook implements IXposedHookLoadPackage {
    private static final String TAG = "TorchBright";
    private static final int MAX_LEVEL = 300;
    private static final int DEFAULT_LEVEL = 160;
    private static volatile int lastLevel = DEFAULT_LEVEL;
    private static final Set<String> seen = Collections.synchronizedSet(new HashSet<String>());

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"miui.systemui.plugin".equals(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded in " + lpparam.processName);
        try {
            hookCharacteristics();
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
        try {
            hookManager();
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }

    // Make the plugin believe the torch supports many strength levels.
    private void hookCharacteristics() {
        XposedHelpers.findAndHookMethod(CameraCharacteristics.class, "get",
                CameraCharacteristics.Key.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        try {
                            String n = ((CameraCharacteristics.Key<?>) p.args[0]).getName();
                            if ("android.flash.info.strengthMaximumLevel".equals(n)) {
                                logOnce(n, p.getResult());
                                p.setResult(MAX_LEVEL);
                            } else if ("android.flash.info.strengthDefaultLevel".equals(n)) {
                                logOnce(n, p.getResult());
                                p.setResult(DEFAULT_LEVEL);
                            }
                        } catch (Throwable t) {
                            XposedBridge.log(t);
                        }
                    }
                });
    }

    // The camera HAL accepts only level 1, so turn the torch on normally
    // and hand the chosen level to the root service through logcat.
    private void hookManager() {
        XposedHelpers.findAndHookMethod(CameraManager.class, "turnOnTorchWithStrengthLevel",
                String.class, int.class, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        try {
                            String id = (String) p.args[0];
                            int lvl = (Integer) p.args[1];
                            if (lvl < 1) lvl = 1;
                            if (lvl > MAX_LEVEL) lvl = MAX_LEVEL;
                            lastLevel = lvl;
                            ((CameraManager) p.thisObject).setTorchMode(id, true);
                            Log.i(TAG, "L:" + lvl);
                            XposedBridge.log(TAG + ": turnOnTorchWithStrengthLevel " + lvl);
                            p.setResult(null);
                        } catch (Throwable t) {
                            XposedBridge.log(t);
                        }
                    }
                });

        XposedHelpers.findAndHookMethod(CameraManager.class, "getTorchStrengthLevel",
                String.class, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        p.setResult(lastLevel);
                    }
                });
    }

    private static void logOnce(String key, Object original) {
        if (seen.add(key)) {
            XposedBridge.log(TAG + ": " + key + " original=" + original);
        }
    }
}
