plugins {
    id("com.android.application")
}

android {
    namespace = "com.torchbright"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.torchbright.hook"
        minSdk = 33
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    compileOnly("de.robv.android.xposed:api:82")
}
