#!/system/bin/sh
MODDIR=${0%/*}
D=/sys/class/leds
L=/data/adb/torchbright_level
MAX=300

while [ "$(getprop sys.boot_completed)" != 1 ]; do sleep 5; done

# install the hook app once
if ! pm path com.torchbright.hook >/dev/null 2>&1; then
  cp "$MODDIR/torchbright.apk" /data/local/tmp/torchbright.apk
  pm install -r /data/local/tmp/torchbright.apk >/dev/null 2>&1
  rm -f /data/local/tmp/torchbright.apk
fi

# slider events from the plugin hook arrive as log lines "L:<level>"
logcat -v raw -s TorchBright:I 2>/dev/null | while read -r line; do
  case "$line" in
    L:[0-9]*)
      N=${line#L:}
      [ "$N" -gt "$MAX" ] 2>/dev/null && N=$MAX
      [ "$N" -lt 1 ] 2>/dev/null && N=1
      echo "$N" > $L
      echo "$N" > $D/led:torch_0/brightness
      sleep 0.2
      echo "$N" > $D/led:torch_0/brightness
      ;;
  esac
done &

# re-apply the saved level every time the flashlight turns on
prev=0
while true; do
  s=$(cat $D/led:switch_0/brightness)
  if [ "$s" = 1 ] && [ "$prev" = 0 ] && [ -f $L ]; then
    sleep 0.2
    cat $L > $D/led:torch_0/brightness
    sleep 0.5
    cat $L > $D/led:torch_0/brightness
  fi
  prev=$s
  sleep 0.3
done
