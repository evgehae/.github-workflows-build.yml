set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/bin/torch 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/listener.sh 0 0 0755
ui_print "- After reboot: enable TorchBright in Vector, scope: miui.systemui.plugin and com.android.systemui"
