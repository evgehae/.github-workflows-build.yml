#!/system/bin/sh
MODDIR=${0%/*}
D=/sys/class/leds
L=/data/adb/torchbright_level

while [ "$(getprop sys.boot_completed)" != 1 ]; do sleep 5; done

# install or update the hook app when the bundled APK changes
SUM=$(md5sum "$MODDIR/torchbright.apk" | cut -d' ' -f1)
if [ "$(cat /data/adb/torchbright_apk_md5 2>/dev/null)" != "$SUM" ] || ! pm path com.torchbright.hook >/dev/null 2>&1; then
  cp "$MODDIR/torchbright.apk" /data/local/tmp/torchbright.apk
  if pm install -r /data/local/tmp/torchbright.apk >/dev/null 2>&1; then
    echo "$SUM" > /data/adb/torchbright_apk_md5
  fi
  rm -f /data/local/tmp/torchbright.apk
fi

# slider listener runs as its own script
sh "$MODDIR/listener.sh" >/dev/null 2>&1 &

# re-apply the saved level every time the flashlight turns on
prev=0
while true; do
  s=$(cat $D/led:switch_0/brightness)
  if [ "$s" = 1 ] && [ "$prev" = 0 ] && [ -f $L ]; then
    sleep 0.2
    cat $L > $D/led:torch_0/brightness
    sleep 0.5
    cat $L > $D/led:torch_0/brightness
  fi
  prev=$s
  sleep 0.3
done
