#!/system/bin/sh
D=/sys/class/leds
L=/data/adb/torchbright_level
MAX=300
LOG=/data/local/tmp/torchbright.log

while true; do
  echo "$(date +%T) listener start" >> $LOG
  logcat -v raw -s TorchBright:I MiFlash_OperationReceiver:I 2>>$LOG | while read -r line; do
    case "$line" in
      L:[0-9]*) N=${line#L:} ;;
      *"strength="*) N=${line#*strength=}; N=${N%% *} ;;
      *) continue ;;
    esac
    case "$N" in ''|*[!0-9]*) continue ;; esac
    [ "$N" -gt "$MAX" ] && N=$MAX
    [ "$N" -lt 1 ] && N=1
    echo "$N" > $L
    echo "$N" > $D/led:torch_0/brightness
  done
  echo "$(date +%T) listener exited" >> $LOG
  sleep 2
done
